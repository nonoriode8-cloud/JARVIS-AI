package com.nelsonville.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var command: EditText
    private val cyan = Color.rgb(90, 220, 255)
    private val pale = Color.rgb(205, 242, 255)
    private val navy = Color.rgb(4, 15, 27)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(navy)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("J.A.R.V.I.S.", 30f, cyan, true))
        page.addView(label("PERSONAL AI SYSTEM  •  VERSION 1.0", 10f, pale))
        page.addView(space(24))

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 100f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(8, 38, 58))
                setStroke(3, cyan)
            }
            elevation = 12f
        }
        page.addView(orb, LinearLayout.LayoutParams(190, 190))
        page.addView(space(14))
        status = label("SYSTEM STANDBY", 15f, cyan, true)
        page.addView(status)
        page.addView(label("READY FOR YOUR COMMAND", 10f, pale))
        page.addView(space(22))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(9, 30, 46))
                setStroke(1, Color.rgb(30, 105, 135))
                cornerRadius = 18f
            }
        }
        page.addView(panel, LinearLayout.LayoutParams(-1, -2))
        panel.addView(label("COMMAND CONSOLE", 11f, cyan, true))
        conversation = TextView(this).apply {
            text = "JARVIS: Good day. I am online and ready to assist you."
            textSize = 14f
            setTextColor(pale)
            setPadding(0, 14, 0, 14)
        }
        panel.addView(conversation)
        command = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            setPadding(12, 10, 12, 10)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(3, 17, 29))
                setStroke(1, cyan)
                cornerRadius = 12f
            }
        }
        panel.addView(command, LinearLayout.LayoutParams(-1, 52))
        page.addView(space(10))

        val send = makeButton("SEND COMMAND")
        page.addView(send, LinearLayout.LayoutParams(-1, 52))
        send.setOnClickListener { val text = command.text.toString().trim(); if (text.isNotEmpty()) { command.text.clear(); handleCommand(text) } }

        val mic = makeButton("🎙  TALK TO JARVIS")
        val micParams = LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 }
        page.addView(mic, micParams)
        mic.setOnClickListener { listen() }

        page.addView(space(18))
        page.addView(label("QUICK COMMANDS", 11f, cyan, true))
        listOf("What time is it?", "What is your name?", "Tell me a joke", "What can you do?").forEach { text ->
            val b = makeButton(text)
            val p = LinearLayout.LayoutParams(-1, 46).apply { topMargin = 8 }
            page.addView(b, p)
            b.setOnClickListener { handleCommand(text) }
        }
        page.addView(space(20))
        page.addView(label("JARVIS AI  •  ANDROID EDITION", 10f, pale))
    }

    private fun handleCommand(input: String) {
        val q = input.lowercase(Locale.getDefault())
        val answer = when {
            "time" in q -> "The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            "date" in q -> "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            "name" in q || "who are you" in q -> "I am JARVIS, your personal assistant."
            "joke" in q -> "Why did the computer go to the doctor? It had a virus."
            "what can you do" in q || "capabilities" in q -> "I can listen to voice commands, speak replies, tell the time and handle basic demo commands. AI services will be connected in a later development step."
            "hello" in q || "good morning" in q || "good evening" in q -> "Hello. I am here and ready to help."
            else -> "I received your command. My live AI brain is not connected yet. That is our next development step."
        }
        conversation.text = "YOU: $input\n\nJARVIS: $answer"
        speak(answer)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "VOICE RECOGNITION UNAVAILABLE"
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
            return
        }
        status.text = "LISTENING..."
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { status.text = "I'M LISTENING..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "PROCESSING..." }
            override fun onError(error: Int) { status.text = "VOICE INPUT ENDED — TRY AGAIN" }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                status.text = "SYSTEM STANDBY"
                if (!words.isNullOrBlank()) handleCommand(words)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            // Prefer an installed voice whose name identifies it as female.
            val female = tts.voices?.firstOrNull { it.name.contains("female", ignoreCase = true) }
            if (female != null) tts.voice = female
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun makeButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(pale)
        isAllCaps = false
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(8, 43, 62))
            setStroke(1, cyan)
            cornerRadius = 12f
        }
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
