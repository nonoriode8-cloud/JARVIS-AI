# JARVIS AI — Android starter project

This is the first native Android foundation for JARVIS. It includes:
- A dark blue sci-fi inspired interface
- Typed commands and quick-command buttons
- Android speech recognition (microphone permission requested at runtime)
- Android text-to-speech responses
- A preference for an installed TTS voice whose name contains `female`

## Build the APK

1. Install **Android Studio** on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `JARVIS-Android` folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the generated APK location. Transfer it to your phone and install it.

## Voice note
The app uses the Android device's speech recognition and text-to-speech engines. A female voice is selected only if the installed engine exposes a voice with `female` in its name. Otherwise, choose/download a female voice in your phone's Text-to-speech settings.

## Current limitations
This is a starter build, not yet connected to a live AI model. Commands are handled locally. The next stage is to add a secure backend that calls an AI API. Do not put a private API key directly in the Android app.
